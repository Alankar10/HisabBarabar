package com.example.hisabbarabar;

import static java.lang.reflect.Array.get;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int member = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView username = (TextView) findViewById(R.id.editTextTextEmailAddress);
        TextView password = (TextView) findViewById(R.id.editTextTextPassword);
        Button button = (Button) findViewById(R.id.button);
    }

    public void loginlayout(View view){
        setContentView(R.layout.secondlayout);
        Button button3 = (Button) findViewById(R.id.button3);
    }
    public void secondlayout(View view){
        setContentView(R.layout.thirdlayout);
        TextView members = (TextView) findViewById(R.id.editTextNumber);
        Button button2 = (Button) findViewById(R.id.button2);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            member = members.getAutofillType();
        }
    }
    public void thirdlayout(View view){
        setContentView(R.layout.fourthlayout);
        TextView names = (TextView) findViewById(R.id.editTextText);
    }
    public void fourthlayout(View view) {
        setContentView(R.layout.fifthlayout);
    }
}
